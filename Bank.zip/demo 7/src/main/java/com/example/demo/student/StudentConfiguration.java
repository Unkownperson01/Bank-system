package com.example.demo.student;

import org.apache.tomcat.jni.Local;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.LocalDate;
import java.util.List;

@Configuration
public class StudentConfiguration {
    
    @Bean
    CommandLineRunner initDatabase(StudentRepository studentRepository) {

        return args -> {
            Student rona = new Student("Rona",
                    LocalDate.of(1998, 10, 17), 
                    23);
            
            Student argimi = new Student("Argimi", 
                    LocalDate.of(1995, 9, 10),
                    25);
            
            studentRepository.saveAll(List.of(rona, argimi));
        };
    }
}
