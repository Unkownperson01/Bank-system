package com.example.demo.student;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "/api/student")
public class StudentController {
    
    private final StudentService studentService;

    @Autowired
    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }


    @GetMapping
    public List<Student> helloWorld(){
      return studentService.getAllStudents();
    }
    
    @PostMapping
    public void registerStudent(@RequestBody Student student){
        studentService.addNewStudent(student);
    }
    
    
    @DeleteMapping(path = "{id}")
    public void removeStudent(@PathVariable Long id){
        studentService.removeStudent(id);
    }
    
    @PutMapping(path = "{id}")
    public void updateStudent(@PathVariable Long id,
                              @RequestParam String name){
        studentService.updateStudent(id, name);
    }
    
    
    
}
