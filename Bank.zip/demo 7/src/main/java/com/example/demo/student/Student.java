package com.example.demo.student;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table
public class Student {
    
    @Id
    @GeneratedValue(generator = "student_seq", strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "student_seq", sequenceName = "student_seq" , allocationSize = 1)
    private Long id;
    private String emri;
    private LocalDate dob;
    private int age;
    
    public Student(String emri, LocalDate dob, int age){
        this.emri = emri;
        this.dob = dob;
        this.age = age;
    }

    public Student(String emri, int age){
        this.emri = emri;
        this.age = age;
    }

    public Student() {
        
    }


    public Long getId() { return id; }
    
    public void setId(Long id) { this.id = id; }

    public String getEmri() {return emri; }

    public void setEmri(String emri) {this.emri = emri;}

    public LocalDate getDob() { return dob;}

    public void setDob(LocalDate dob) {this.dob = dob;}

    public int getAge() { return age; }

    public void setAge(int age) { this.age = age;}
}
